/************************************************************************************

Copyright (c) 2001-2016  University of Washington Extension.

Module Name:

    tasks.c

Module Description:

    The tasks that are executed by the test application.

2016/2 Nick Strathy adapted it for NUCLEO-F401RE 

************************************************************************************/
#include <stdarg.h>

#include "bsp.h"
#include "print.h"
#include "mp3Util.h"
#include "os_cpu.h"

#include <Adafruit_GFX.h>    // Core graphics library
#include <Adafruit_ILI9341.h>
#include <Adafruit_FT6206.h>

Adafruit_ILI9341 lcdCtrl = Adafruit_ILI9341(); // The LCD controller

Adafruit_FT6206 touchCtrl = Adafruit_FT6206(); // The touch controller

#define PENRADIUS 3

long MapTouchToScreen(long x, long in_min, long in_max, long out_min, long out_max)
{
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}


#include "train_crossing.h"

#define BUFSIZE 256

typedef enum
{
  INPUTCOMMAND_NONE,
  INPUTCOMMAND_PLAY,
  INPUTCOMMAND_STOP,
//  INPUTCOMMAND_VOLUP,
//  INPUTCOMMAND_VOLDOWN,
  INPUTCOMMAND_PAUSE,
} InputCommandEnum;


/************************************************************************************

   Allocate the stacks for each task.
   The maximum number of tasks the application can have is defined by OS_MAX_TASKS in os_cfg.h

************************************************************************************/

static OS_STK   LcdTouchDemoTaskStk[APP_CFG_TASK_START_STK_SIZE];
static OS_STK   Mp3DemoTaskStk[APP_CFG_TASK_START_STK_SIZE];
static OS_STK   StatusTaskStk[APP_CFG_TASK_START_STK_SIZE];

     
// Task prototypes
void LcdTouchDemoTask(void* pdata);
void Mp3DemoTask(void* pdata);
void StatusTask(void* pdata);
INT8U InputEncoder(int16_t, int16_t);
InputCommandEnum InputEncoder1(int16_t, int16_t);
//void ScreenDisplay(InputCommandEnum);


// Useful functions
void PrintToLcdWithBuf(char *buf, int size, char *format, ...);

// Globals
BOOLEAN nextSong = OS_FALSE;
InputCommandEnum status = INPUTCOMMAND_NONE;
#define QMAXENTRIES 1
void * qMsgVPtrs[QMAXENTRIES];
OS_EVENT *qMsg;
OS_EVENT *mySem;
OS_EVENT *mbox;

/************************************************************************************

   This task is the initial task running, started by main(). It starts
   the system tick timer and creates all the other tasks. Then it deletes itself.

************************************************************************************/
void StartupTask(void* pdata)
{
	char buf[BUFSIZE];

    PjdfErrCode pjdfErr;
    INT32U length;
    static HANDLE hSD = 0;
    static HANDLE hSPI = 0;

    qMsg = OSQCreate(qMsgVPtrs, QMAXENTRIES);
    mySem = OSSemCreate(1);
    mbox= OSMboxCreate(NULL);
    
    PrintWithBuf(buf, BUFSIZE, "StartupTask: Begin\n");
    PrintWithBuf(buf, BUFSIZE, "StartupTask: Starting timer tick\n");

    // Start the system tick
    OS_CPU_SysTickInit(OS_TICKS_PER_SEC);
    
    // Initialize SD card
    PrintWithBuf(buf, PRINTBUFMAX, "Opening handle to SD driver: %s\n", PJDF_DEVICE_ID_SD_ADAFRUIT);
    hSD = Open(PJDF_DEVICE_ID_SD_ADAFRUIT, 0);
    if (!PJDF_IS_VALID_HANDLE(hSD)) while(1);


    PrintWithBuf(buf, PRINTBUFMAX, "Opening SD SPI driver: %s\n", SD_SPI_DEVICE_ID);
    // We talk to the SD controller over a SPI interface therefore
    // open an instance of that SPI driver and pass the handle to 
    // the SD driver.
    hSPI = Open(SD_SPI_DEVICE_ID, 0);
    if (!PJDF_IS_VALID_HANDLE(hSPI)) while(1);
    
    length = sizeof(HANDLE);
    pjdfErr = Ioctl(hSD, PJDF_CTRL_SD_SET_SPI_HANDLE, &hSPI, &length);
    if(PJDF_IS_ERROR(pjdfErr)) while(1);

    // Create the test tasks
    PrintWithBuf(buf, BUFSIZE, "StartupTask: Creating the application tasks\n");

    // The maximum number of tasks the application can have is defined by OS_MAX_TASKS in os_cfg.h
    OSTaskCreate(Mp3DemoTask, (void*)0, &Mp3DemoTaskStk[APP_CFG_TASK_START_STK_SIZE-1], APP_TASK_TEST1_PRIO);
    OSTaskCreate(LcdTouchDemoTask, (void*)0, &LcdTouchDemoTaskStk[APP_CFG_TASK_START_STK_SIZE-1], APP_TASK_TEST2_PRIO);
    OSTaskCreate(StatusTask, (void*)0, &StatusTaskStk[APP_CFG_TASK_START_STK_SIZE-1], APP_TASK_TEST3_PRIO);

    // Delete ourselves, letting the work be done in the new tasks.
    PrintWithBuf(buf, BUFSIZE, "StartupTask: deleting self\n");
    OSTaskDel(OS_PRIO_SELF);
}

static void DrawLcdContents()
{
    char buf[BUFSIZE];
    lcdCtrl.fillScreen(ILI9341_BLACK);
    
    // Print a message on the LCD
//    lcdCtrl.setCursor(40, 60);
//    lcdCtrl.setTextColor(ILI9341_PURPLE);  
//    lcdCtrl.setTextSize(2);
//    PrintToLcdWithBuf(buf, BUFSIZE, "Hello World!");
    
    //lcdCtrl.drawTriangle(30, 50); //int16_t x0, int16_t y0, int16_t x1, int16_t y1,
			    //int16_t x2, int16_t y2, uint16_t color
    //lcdCtrl.drawRect(120, 80, 20, 10,ILI9341_RED ); //int16_t x, int16_t y,
                        //int16_t w, int16_t h,
                        //uint16_t color
    //"PLAY" Button
    lcdCtrl.fillRoundRect(10, 95, 100 , 50, 10, ILI9341_DARKGREY);
    lcdCtrl.setCursor(15, 107);
    lcdCtrl.setTextColor(ILI9341_BLACK); 
    lcdCtrl.setTextSize(4);
    PrintToLcdWithBuf(buf, BUFSIZE, "PLAY");
    
    //"STOP" Button
    lcdCtrl.fillRoundRect(135, 95, 100 , 50, 10, ILI9341_DARKGREY);
    lcdCtrl.setCursor(140, 107);
    lcdCtrl.setTextColor(ILI9341_BLACK); 
    lcdCtrl.setTextSize(4);
    PrintToLcdWithBuf(buf, BUFSIZE, "STOP");
    
    //"PAUSE" Button
    lcdCtrl.fillRoundRect(10, 175, 100 , 50, 10, ILI9341_DARKGREY);
    lcdCtrl.setCursor(15, 182);
    lcdCtrl.setTextColor(ILI9341_BLACK); 
    lcdCtrl.setTextSize(3);
    PrintToLcdWithBuf(buf, BUFSIZE, "PAUSE");
    
    //"VOL +" Button
    lcdCtrl.fillRoundRect(135, 175, 100 , 50, 10, ILI9341_DARKGREY);
    
    //"VOL -" Button
    lcdCtrl.fillRoundRect(135, 255, 100 , 50, 10, ILI9341_DARKGREY);
     
}

/************************************************************************************

   Runs LCD/Touch demo code

************************************************************************************/
void LcdTouchDemoTask(void* pdata)
{
    PjdfErrCode pjdfErr;
    INT32U length;
    INT8U err;
    

    char buf[BUFSIZE];
    PrintWithBuf(buf, BUFSIZE, "LcdTouchDemoTask: starting\n");

    PrintWithBuf(buf, BUFSIZE, "Opening LCD driver: %s\n", PJDF_DEVICE_ID_LCD_ILI9341);
    // Open handle to the LCD driver
    HANDLE hLcd = Open(PJDF_DEVICE_ID_LCD_ILI9341, 0);
    if (!PJDF_IS_VALID_HANDLE(hLcd)) while(1);

	PrintWithBuf(buf, BUFSIZE, "Opening LCD SPI driver: %s\n", LCD_SPI_DEVICE_ID);
    // We talk to the LCD controller over a SPI interface therefore
    // open an instance of that SPI driver and pass the handle to 
    // the LCD driver.
    HANDLE hSPI = Open(LCD_SPI_DEVICE_ID, 0);
    if (!PJDF_IS_VALID_HANDLE(hSPI)) while(1);

    length = sizeof(HANDLE);
    pjdfErr = Ioctl(hLcd, PJDF_CTRL_LCD_SET_SPI_HANDLE, &hSPI , &length);
    if(PJDF_IS_ERROR(pjdfErr)) while(1);

	PrintWithBuf(buf, BUFSIZE, "Initializing LCD controller\n");
    lcdCtrl.setPjdfHandle(hLcd);
    lcdCtrl.begin();

    DrawLcdContents();
  
    //int currentcolor = ILI9341_GREEN;
    
    PrintWithBuf(buf, BUFSIZE, "Opening I2C driver: %s\n", PJDF_DEVICE_ID_I2C1);
    HANDLE hI2C = Open(PJDF_DEVICE_ID_I2C1, 0);
    if (!PJDF_IS_VALID_HANDLE(hI2C)) while(1);
   
    length = sizeof(HANDLE);
    //OSFlagPend(myFlags, 0x1, OS_FLAG_WAIT_CLR_ALL, 0, &err);
    //CPU_CRITICAL_ENTER;
    pjdfErr = Ioctl(hI2C, PJDF_CTRL_I2C_SET_DEVICE_ADDRESS, (void*)FT6206_ADDR , &length);
    if(PJDF_IS_ERROR(pjdfErr)) while(1);

    touchCtrl.setPjdfHandle(hI2C);
        PrintWithBuf(buf, BUFSIZE, "Initializing FT6206 touchscreen controller\n");
        //touchCtrl.begin(40);
    if (! touchCtrl.begin(40)) {  // pass in 'sensitivity' coefficient
        PrintWithBuf(buf, BUFSIZE, "Couldn't start FT6206 touchscreen controller\n");
        while (1);
    }

    while (1) { 
        boolean touched = false;
        
        // TODO: Poll for a touch on the touch panel
        // <Your code here>
        // <hint: Call a function provided by touchCtrl
        
        touched = touchCtrl.touched();
        
        if (! touched) {
            OSTimeDly(5);
            continue;
        }
        
        TS_Point rawPoint;
       
        // TODO: Retrieve a point  
        // <Your code here>
        rawPoint = touchCtrl.getPoint();

        if (rawPoint.x == 0 && rawPoint.y == 0)
        {
            continue; // usually spurious, so ignore
        }
        
        // transform touch orientation to screen orientation.
        TS_Point p = TS_Point();
        p.x = MapTouchToScreen(rawPoint.x, 0, ILI9341_TFTWIDTH, ILI9341_TFTWIDTH, 0);
        p.y = MapTouchToScreen(rawPoint.y, 0, ILI9341_TFTHEIGHT, ILI9341_TFTHEIGHT, 0);
        
        InputCommandEnum command = InputEncoder1(p.x, p.y);
        //INT8U input = InputEncoder(p.x, p.y);
        
        //ScreenDisplay(input);
        //err = OSQPost(qMsg, &input);
        err = OSQPost(qMsg, &command);
        OSMboxPost(mbox, &command);

        //if(temp < 0){while(1);}
        //enum InputCommandEnum input;
        //input = temp;
        
        //lcdCtrl.fillCircle(p.x, p.y, PENRADIUS, currentcolor);
        //OSFlagPost(myFlags, 0x1, OS_FLAG_SET, &err);
        //CPU_CRITICAL_EXIT();
        //OSTimeDly(1);
    }
}
/************************************************************************************

   Runs MP3 demo code

************************************************************************************/
void Mp3DemoTask(void* pdata)
{
    PjdfErrCode pjdfErr;
    INT32U length;
    INT8U err;
    OSTimeDly(2000); // Allow other task to initialize LCD before we use it.
    
	char buf[BUFSIZE];
	PrintWithBuf(buf, BUFSIZE, "Mp3DemoTask: starting\n");

	PrintWithBuf(buf, BUFSIZE, "Opening MP3 driver: %s\n", PJDF_DEVICE_ID_MP3_VS1053);
    // Open handle to the MP3 decoder driver
    HANDLE hMp3 = Open(PJDF_DEVICE_ID_MP3_VS1053, 0);
    if (!PJDF_IS_VALID_HANDLE(hMp3)) while(1);

	PrintWithBuf(buf, BUFSIZE, "Opening MP3 SPI driver: %s\n", MP3_SPI_DEVICE_ID);
    // We talk to the MP3 decoder over a SPI interface therefore
    // open an instance of that SPI driver and pass the handle to 
    // the MP3 driver.
    HANDLE hSPI = Open(MP3_SPI_DEVICE_ID, 0);
    if (!PJDF_IS_VALID_HANDLE(hSPI)) while(1);

    length = sizeof(HANDLE);
    pjdfErr = Ioctl(hMp3, PJDF_CTRL_MP3_SET_SPI_HANDLE, &hSPI, &length);
    if(PJDF_IS_ERROR(pjdfErr)) while(1);

    // Send initialization data to the MP3 decoder and run a test
    PrintWithBuf(buf, BUFSIZE, "Starting MP3 device test\n");
    Mp3Init(hMp3);
    int count = 0;
    
    while (1)
    {
       
        //OSTimeDly(100);
        InputCommandEnum *command = (InputCommandEnum*)OSMboxPend(mbox, 0, &err);
        if(*command == INPUTCOMMAND_PLAY){
          PrintWithBuf(buf, BUFSIZE, "Begin streaming sound file  count=%d\n", ++count);
          Mp3Stream(hMp3, (INT8U*)Train_Crossing, sizeof(Train_Crossing)); 
          PrintWithBuf(buf, BUFSIZE, "Done streaming sound file  count=%d\n", count);
        }else{
          
        }
          OSSemPend(mySem, 0, &err);
            status = INPUTCOMMAND_STOP;
            err = OSQPost(qMsg, &status);
          OSSemPost(mySem);
    }
}

void StatusTask(void* pdata)
{
    char buf[BUFSIZE];
    INT8U err;
    //InputCommandEnum* input;
    while(1){
      //INT8U *status = (INT8U*)OSQPend(qMsg, 0, &err);
      InputCommandEnum *command = (InputCommandEnum*)OSQPend(qMsg, 0, &err);
      
      lcdCtrl.fillRect(0, 40, 240, 50, ILI9341_BLACK);
      lcdCtrl.setCursor(100, 70);
      lcdCtrl.setTextColor(ILI9341_PURPLE);  
      lcdCtrl.setTextSize(2);
      
      switch(*command){
      //case 1:
      case INPUTCOMMAND_PLAY:
        PrintToLcdWithBuf(buf, BUFSIZE, "PLAY...");  
        break;
      //case 2:
      case INPUTCOMMAND_STOP:
        PrintToLcdWithBuf(buf, BUFSIZE, "STOP!");
        break;   
      //case 3:
      case INPUTCOMMAND_PAUSE:
        PrintToLcdWithBuf(buf, BUFSIZE, "PAUSE..."); 
        break;
    //  default: 
    //    PrintToLcdWithBuf(buf, BUFSIZE, "Hello!");    
      }
    }
  //OSTimeDly(100);
}


// Renders a character at the current cursor position on the LCD
static void PrintCharToLcd(char c)
{
    lcdCtrl.write(c);
}

/************************************************************************************

   Print a formated string with the given buffer to LCD.
   Each task should use its own buffer to prevent data corruption.

************************************************************************************/
void PrintToLcdWithBuf(char *buf, int size, char *format, ...)
{
    va_list args;
    va_start(args, format);
    PrintToDeviceWithBuf(PrintCharToLcd, buf, size, format, args);
    va_end(args);
}

//INT8U InputEncoder(int16_t x, int16_t y){
//  //InputCommandEnum command = INPUTCOMMAND_NONE;
//  INT8U command;
//  if((x >= 10 && x <= 110) && (y>=95 && y<=145)){
//    command = 1;
//    lcdCtrl.fillCircle(x, y, PENRADIUS, ILI9341_BLUE);
//  }else if((x >= 135 && x <= 235) && (y >= 95 && y <= 145)){
//    command = 2;
//    lcdCtrl.fillCircle(x, y, PENRADIUS, ILI9341_RED);
//  }else if((x >= 10 && x <= 110) && (y >= 175 && y <= 225)){
//    command = 3;
//    lcdCtrl.fillCircle(x, y, PENRADIUS, ILI9341_PURPLE);
//  }else{
//    command = 4;
//    //lcdCtrl.fillCircle(x, y, PENRADIUS, ILI9341_GREEN);
//  }
//  
//  
//  return command;
//  
//}

InputCommandEnum InputEncoder1(int16_t x, int16_t y){
  //InputCommandEnum command;
  INT8U err;
  OSSemPend(mySem, 0, &err);
  if((x >= 10 && x <= 110) && (y>=95 && y<=145)){
    status = INPUTCOMMAND_PLAY;
  }else if((x >= 135 && x <= 235) && (y >= 95 && y <= 145)){
    status = INPUTCOMMAND_STOP;
  }else if((x >= 10 && x <= 110) && (y >= 175 && y <= 225)){
    status = INPUTCOMMAND_PAUSE;
  }
  OSSemPost(mySem);

  return status;
}





